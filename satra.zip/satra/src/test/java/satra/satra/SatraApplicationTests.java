package satra.satra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SatraApplicationTests {

	@Test
	void contextLoads() {
	}

}
